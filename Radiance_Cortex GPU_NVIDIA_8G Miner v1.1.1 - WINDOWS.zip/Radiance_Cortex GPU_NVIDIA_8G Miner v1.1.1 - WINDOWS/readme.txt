#### Radiance Miner
Now 7.2G of VRAM would be enough, which making mid end mining GPUs like NVIDIA 1080 and P104 able to mine CTXC

#### v1.0.0 features
Radiance v1.0.0 only supports NVIDIA 8G GPUs, like 1080 and P104
Windows only
Do not use it on high end GPUs like 1080ti and 2080ti
Haven't considered developing under OpenCL, might consider if Radiance gets popular

#### How To Run
1. modify the miner.ini
	addr : the remote pool ip:port, such cuckoo.cortexmint.com:8008
	account : the cortex wallet address
	devices : the gpu id you want to mining
	worker : thr worker name

2. run the run.bat
