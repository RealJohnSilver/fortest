### Radiance Miner
1. Now 7.2G of VRAM would be enough, which making mid end mining GPUs like NVIDIA 1080 and P104 able to mine CTXC. 

### v1.1.1 features
1. supports NVIDIA 8G and 11G GPU on linux system
2. only supports NVIDIA 8G GPU on windows system 
3. Haven't considered developing under OpenCL, might consider if Radiance gets popular

### How To Run
1. modify the start.sh
	-worker: the worker name
	-pool_uri: the remote pool uri, example: cuckoo.cortexmint.com:8008
	-device: the id of the GPUs you wish to use for mining
	-account: your address from Cortex Mainnet (Not ERC20 token address!)
    -8g: if you are using 8GB GPUs
    -11g: if you are using 11GB GPUs
2. bash start.sh
